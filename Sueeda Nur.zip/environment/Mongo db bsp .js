

var express  = require('express');
var app      = express();
var port     = process.env.PORT || 8080;
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var mongoose = require('mongoose');
var passport = require('passport');
const https = require("https");
const fs= require("fs");
var path=require("path");

var userDataSchema = new mongoose.Schema({
    Benutzername: string,
    Email: 
})

app.use('/', express.static(path.join(__dirname,'public')));
//var User = require('./models/user')

 // server.js

// load the things we need


const MongoClient = require('mongodb').MongoClient;

const assert = require('assert');

// Connection URL

const url = 'mongodb://localhost:27017';

 

// Database Name

const dbName = 'uebung';
// set the view engine to ejs

app.set('view engine', 'ejs');

 

// use res.render to load up an ejs view file

 

// index page 

app.get('/', function(req, res) {
    console.log(req.query)

    MongoClient.connect(url, function(err, client) {

  assert.equal(null, err);

  console.log("Connected successfully to server");

 

  const db = client.db('uebung');

  

  const collection = db.collection('documents');

  // Find some documents

  collection.find({}).toArray(function(err, docs) {

    assert.equal(err, null);

    console.log("Found the following records");

    console.log(docs)

    res.render('index',{test:docs});
 
  });

  client.close();

});
});




// about page 
app.get('/index', function(req, res) {

    res.render('index.ejs');

});

app.get('/index2', function(req, res) {

    res.render('index2.ejs');

});
app.get('/index3', function(req, res) {  
 
 
    res.render('index3.ejs');

});

app.get('/index4', function(req, res) {

    res.render('index4');

});
app.get('/index5', function(req, res) {

    res.render('index5.ejs');

});
app.get('/index6', function(req, res) {

    res.render('index6.ejs');

});
app.get('/index7', function(req, res) {

    res.render('index7.ejs');

});
app.use("/views",express.static("index2"));

https.createServer({
  key: fs.readFileSync('server.key'),
  cert: fs.readFileSync('server.cert')
}, app).listen(4443, () => {
  console.log('Listening...');
})


// Use connect method to connect to the server

