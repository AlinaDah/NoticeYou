const http= require("http");
const fs = require("fs");
http.createServer(function(request,response){
    response.writeHead(200);
    response.end(fs.readFileSync("Hallo Welt.html"));
}).listen(8080);