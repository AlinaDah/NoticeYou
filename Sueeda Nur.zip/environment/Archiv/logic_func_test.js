var assert = require("assert");
var Logic = require("./class");
let logic= new Logic(1,1);

//First describe the test suite.
describe('Testing the logical module logic.js', function() {
    //Testing all cases individually.
    it('NAND 0,0 should return 1', function() {
        let o = logic.NAND(0,0);
        assert.equal(o,1);
    });
    it('NAND 0,1 should return 0', function() {
        let o = logic.NAND(0,1);
        assert.equal(o,true);
    });
    it('NAND 1,0 should return 0', function() {
        let o = logic.NAND(1,0);
        assert.equal(o,true);
    });
    it('NAND 1,1 should return 0', function() {
        let o = logic.NAND(1,1);
        assert.equal(o,false);
    });
});