class logic {
    constructor(a,b){
        this.a=a
        this.b=b 
    }
    AND(a,b){
        let i= this.NAND(a,b);
        return this.NAND(0,0);
    }
    NAND(a,b){
        var self = this;
        return !(a&&b);
    }
}
module.exports = logic;
//bitweise AND
bitweiseAND(a.length,b.length){ //teste länge

if (a.length === b.length){
    let 
}
    
}
//for schleife
let text = '';
let zahl = 10;
let i;
for ( i=0; i<=zahl; i++ ) {
   text = text + i + ' mal 3 ist ' + i*3 + '\n';//3er Reihe
}
console.log (text);


//for ([1,1,0,0,1,0]; [a&&b]; [1,0,1,0,1,0]); ({1,0,0,0,1,0})