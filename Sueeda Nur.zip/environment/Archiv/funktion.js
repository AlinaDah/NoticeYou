function multiply(num1,num2){
    return num1*num2

}
//hier wird der code tatsächlich ausgeführt
let x= multiply(3,5);
console.log("multiply (15) 3*5=",x);

function easyCalc(what,num1,num2){
    return what(num1,num2);

}

console.log("Funktionsreferenz: easycalc(36):",easyCalc(multiply,6,6));

function test(what,num1,num2){
    var a=10;
    //funktione sind erste objekte erster ordnung
    
    function calc(what,num1,num2){
        return what(a,a);
    }
    return calc(what,num1,num2);
}
function testClosure(){
    console.log("closure(25):",test(multiply,5,5));
}
testClosure();

