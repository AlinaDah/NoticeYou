function cbT () {
    return "TRUE";
}
function cbF(){
    return "FALSE";
}
function test(wert,falseCB,trueCB){
    if (wert) 
    return trueCB();
    else
    return falseCB();
}
console.log("true:",test(true,cbF,cbT));
console.log("false:",test(false,cbF,cbT));