var assert = require('assert');
var logic =require('./logic');


describe('Testen der logischen Funktionen',function(){
    it ('NAND 0,0 sollte 1 zurückgeben',function(){assert.equal(1,logic.NAND(0,0));});});

describe('Testen der logischen Funktionen',function(){
    it ('NAND 0,1 sollte 1 zurückgeben',function(){assert.equal(1,logic.NAND(0,1));});});

describe('Testen der logischen Funktionen',function(){
    it ('NAND 1,0 sollte 1 zurückgeben',function(){assert.equal(1,logic.NAND(1,0));});});

describe('Testen der logischen Funktionen',function(){
    it ('NAND 1,1 sollte 0 zurückgeben',function(){assert.equal(0,logic.NAND(1,1));});});


