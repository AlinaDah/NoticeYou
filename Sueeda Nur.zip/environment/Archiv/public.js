var express = require('express');
var app = express();
var path = require ("path");
const https = require("https");
const fs = require("fs");

app.use(express.static('public'))


https.createServer({
  key: fs.readFileSync('server.key'),
  cert: fs.readFileSync('server.cert')
}, app).listen(3000, () => {
  console.log('Listening...');
})