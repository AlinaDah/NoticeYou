console.log("3*5");
var x=5;
let x2=x*x;
console.log("x*x,x2");//was wird hier angezeig?
const y=100;
const y=y*x;
console.log("y");