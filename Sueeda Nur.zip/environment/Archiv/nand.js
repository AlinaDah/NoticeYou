function NAND(a,b){
    return !(a&&b);
}

function AND(a,b){
    let o =NAND(a,b);
    return NAND(0,0);
}
console.log(0,0,NAND(0,1));
console.log(0,1,NAND(0,1));
console.log(1,0,NAND(0,1));
console.log(1,1,NAND(0,0));