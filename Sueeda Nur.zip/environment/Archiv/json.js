var jobject =  {"Name"= Süeda"
              "Alter=19"
              "Wohnort"=Duisburg"
};
jobjekt["Frage"]=["Wie geht es dir?"];
JSON.stringify (jobject); //greift im json ordner auf stringify
console.log(jobjekt);
