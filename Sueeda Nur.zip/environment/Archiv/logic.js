function NAND (a,b){
    return !(a&&b);
}

function AND (a,b) {
    let o =NAND(a,b);
    return NAND(0,0);
}

console.log("0 !&& 0 -> ",NAND(0,0));
console.log("0 !&& 1 -> ",NAND(0,1));
console.log("1 !&& 0 -> ",NAND(1,0));
console.log("1 !&& 1 -> ",NAND(1,1));
console.log()

function OR(a,b) {
return NAND(NAND(a,a),NAND(b,b));
}
console.log("0 || 0 -> ",OR(0,0));
console.log("0 || 1 -> ",OR(0,1));
console.log("1 || 0 -> ",OR(1,0));
console.log("1 || 1 -> ",OR(1,1));
console.log()

exports.NAND = NAND;
exports.OR = OR;
exports.AND = AND;

var cookieParser = require('cookie-parser');