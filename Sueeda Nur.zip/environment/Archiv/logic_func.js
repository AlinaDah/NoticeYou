/**
 * The NAND funtion takes two inputs a and b and performs a logic AND operation
 * on them. It then returns the negated result.
 * @param a input (true|false|0|1)
 * @param b input (true|false|0|1)
 * @return true if (0,0; 0,1; 1,0) and false if (1,1).
 **/
function NAND(a,b) {
    return !(a && b);
}

/**
 * The OR funtion takes two inputs a and b and performs a logic OR operation
 * on them. 
 * @param a input (true|false|0|1)
 * @param b input (true|false|0|1)
 * @return true if (0,1; 1,0, 1,1) and false if (0,0).
 **/
function OR(a,b) {
    return NAND(NAND(a,a),NAND(b,b)); 
}

/**
 * The AND funtion takes two inputs a and b and performs a logic AND operation
 * on them.
 * @param a input (true|false|0|1)
 * @param b input (true|false|0|1)
 * @return false if (0,0; 0,1; 1,0) and true if (1,1).
 **/
function AND(a,b) {
    let i = NAND(a,b);
    return NAND(i,i); 
}

/**
 * The NOT funtion takes one input and negates it.
 * @param a input (true|false|0|1)
 * @return true if (0) and false if (1).
 **/
function NOT(a) {
    return NAND(a,a); 
}

exports.NAND = NAND;
exports.OR = OR;
exports.NOT = NOT;
exports.AND = AND;