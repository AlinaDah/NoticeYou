var mongoose=require('mongoose');
var passportLocalMongoose =require('passport-local-mongoose');

var userDataSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String,
    password2: String,
     anrede: String,
    firstname: String,
    lastname: String,
    geschlecht: String,
    krankenhaus: String,
    krankheit: String,
    Datum: String,
    SystolischerDruck: String,
    DiastolischerDruck: String,
    Puls: String,
    Datum: String,
    Gewicht: String,
    Tageszeit: String,
    Medikament: String,
    Dosis: String,
    input2: String
},{collection: 'userdata'});

userDataSchema.plugin(passportLocalMongoose);
module.exports=mongoose.model('User', userDataSchema);