/*self.addEventListener('fetch', function(event) {
 if (/\.PNG$/.test(event.request.url)) {
 event.respondWith(fetch('/public/Icon Applikation.PNG’));
 }
});*/


self.addEventListener('install', function(e) {
 e.waitUntil(
   caches.open('video-store').then(function(cache) {
     return cache.addAll([
       '/views/web/index0.ejs/',
       '/views/web/index1.ejs/',
       '/views/web/index2.ejs/',
       '/views/web/index3.ejs/',
       '/views/web/index4.ejs/',
       '/views/web/index5.ejs/',
       '/views/web/index6.ejs/',
       '/views/web/index7.ejs/',
       '/public/web/css/style.css',
       '/public/web/css/style0.css',
       '/public/web/css/style2.css',
       '/public/web/css/style3.css',
       '/public/web/css/style4.css',
       '/public/web/css/style5.css',
       '/public/web/css/style6.css',
       '/public/web/css/style7.css',
       '/public/web/css/jquery-ui.css',
       '/public/web/images/o.PNG'
       
     ]);
   })
 );
});

self.addEventListener('fetch', function(e) {
  console.log(e.request.url);
  e.respondWith(
    caches.match(e.request).then(function(response) {
      return response || fetch(e.request);
    })
  );
});