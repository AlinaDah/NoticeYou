var express  = require('express');
var app      = express();
var port     = process.env.PORT || 8080;
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/userdata');
var passport = require('passport');
const https = require("https");
const fs= require("fs");
var path=require("path");


app.use(bodyParser.urlencoded({extended:true}));

var connection = mongoose.connection;
connection.once('open', function(){
    connection.db.collection('userdata', function(err, collection){
        collection.find({}).toArray(function(err, data){
            console.log(data);
        });
    });
});


var userDataSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String,
    password2: String,
    anrede: String,
    firstname: String,
    lastname: String,
    geschlecht: String,
    krankenhaus: String,
    mehrzeilig: String,
    Datum: String,
    SystolischerDruck: String,
    DiastolischerDruck: String,
    Puls: String,
    Datum: String,
    Gewicht: String,
    Tageszeit: String,
    Medikament: String,
    Dosis: String,
    input2: String
},{collection: 'userdata'});
var userData = mongoose.model('userData', userDataSchema);

app.use('/', express.static(path.join(__dirname,'public')));
//var User = require('./models/user')

 // server.js

// load the things we need



app.set('view engine', 'ejs');

 

// use res.render to load up an ejs view file

 

// index page 

app.get('/', function(req, res) {
    console.log(req.query);
    res.render('index');
});




// about page 
app.get('/index', function(req, res) {

    res.render('index.ejs');

});
app.post('/insert', function(req, res) {
    var variablen = {
        name: req.body.name,
        email: req.body.email,
        password: req.body.password,
        password2: req.body.password2
    };
    var data = new userData(variablen);
    data.save();
    console.log(req.body);
    res.render('leer.ejs', {'variable':variablen});
});


app.get('/index2', function(req, res) {

    res.render('index2.ejs');


});
app.get('/index3', function(req, res) {  
    var connection = mongoose.connection;
   /*connection.once('open', function(){
    connection.db.collection('userdata', function(err, collection){
        collection.find({name: req.body.name}).toArray(function(err, data){
    console.log("zeile 107",data);
    res.render('index3.ejs',{ud:data});
            console.log(data);
        });
    });
});*/
    res.render('index3.ejs');
});



app.post('/insert3', function(req, res) {
var variablen ={
    anrede: req.body.anrede,
    firstname: req.body.firstname,
    lastname: req.body.lastname,
    geschlecht: req.body.geschlecht,
    krankenhaus: req.body.krankenhaus,
    mehrzeilig: req.body.mehrzeilig
};
var data = new userData (variablen);
data.save();
console.log(req.body);
/*userData.register(new userData({
    anrede: req.body.anrede,
    firstname: req.body.firstname,
    lastname: req.body.lastname,
    geschlecht: req.body.geschlecht,
    krankenhaus: req.body.krankenhaus,
    mehrzeilig: req.body.mehrzeilig
}), function(err, userData){
    if(err){
        console.log(err);
        return res.render('index3');
    }
    passport.authenticate('local')(req,res, function(){
        res.redirect('/views/'+req.body.name);
    });
});
console.log(req.body);*/
 
    res.render('leer3.ejs', {'variable':variablen});

});


app.get('/index4', function(req, res) {

    res.render('index4');

});


app.get('/index5', function(req, res) {
    
     res.render('index5.ejs');
});


 app.post('/insert5', function(req, res) {
var variablen ={
    Datum: req.body.Datum,
    SystolischerDruck: req.body.SystolischerDruck,
    DiastolischerDruck: req.body.DiastolischerDruck,
    Puls: req.body.Puls
};
var data = new userData (variablen);
data.save();
console.log(req.body);

    res.render('leer5.ejs', {'variable':variablen});


});
app.get('/index6', function(req, res) {
    
     res.render('index6.ejs');
});

 app.post('/insert6', function(req, res) {
var variablen ={
    Datum: req.body.Datum,
    Gewicht: req.body.Gewicht
};
var data = new userData (variablen);
data.save();
console.log(req.body);

    res.render('leer6.ejs', {'variable':variablen});


});
app.get('/index7', function(req, res) {
    
     res.render('index7.ejs');
});

app.post('/insert7', function(req, res) {
var variablen ={
    Tageszeit: req.body.Tageszeit,
    Medikament: req.body.Medikament,
    Dosis: req.body.Dosis,
    input2: req.body.input2
};
var data = new userData (variablen);
data.save();
console.log(req.body);

    res.render('leer7.ejs', {'variable':variablen});

});
app.use("/views",express.static("index2"));



// Use connect method to connect to the server


app.get('/get-data', function(req, res, next) {
  userData.find()
      .then(function(doc) {
        res.render('leer', {variablen: doc});
      });
});

app.get('/get-data', function(req, res, next) {
  userData.find()
      .then(function(doc) {
        res.render('leer3', {variablen: doc});
      });
});

app.get('/get-data', function(req, res, next) {
  userData.find()
      .then(function(doc) {
        res.render('leer5', {variablen: doc});
      });
});

app.get('/get-data', function(req, res, next) {
  userData.find()
      .then(function(doc) {
        res.render('leer6', {variablen: doc});
      });
});

app.get('/get-data', function(req, res, next) {
  userData.find()
      .then(function(doc) {
        res.render('leer7', {variablen: doc});
      });
});
 
https.createServer({
  key: fs.readFileSync('server.key'),
  cert: fs.readFileSync('server.cert')
}, app).listen(4443, () => {
  console.log('Listening...');
})
